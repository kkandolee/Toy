﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : Character
{
    public GameObject PlayerCharacter;
    public Player PlayerCharacterComponent;
    // Start is called before the first frame update
    void Start()
    {
        CharacterSetting();       
    }

    void FixedUpdate()
    {
        if (isDie == true)
            return;

        //hp가 다되면 소멸
        if (HP <= 0 && isDie == false)
        {
            isDie = true;
            animator.Play("DieMonster");
        }
            
        //캐릭터를 바라보도록 설정
        if (transform.position.y < PlayerCharacter.transform.position.y)
        {
            if(Vector2.Distance(PlayerCharacter.transform.position, transform.position) <= Range)
            {
                CurrentStatus = STATUS.ATTACK;
                animator.Play("AttackMonsterBack");
            }
            else
            {
                CurrentStatus = STATUS.IDLE;
                animator.Play("IdleMonsterBack");
            }

            CharacterDirection_X(PlayerCharacter.transform.position);

        }
        else
        {
            if(Vector2.Distance(PlayerCharacter.transform.position, transform.position) <= Range)
            {
                CurrentStatus = STATUS.ATTACK;
                animator.Play("AttackMonster");
            }
            else
            {
                CurrentStatus = STATUS.IDLE;
                animator.Play("IdleMonster");
            }

            CharacterDirection_X(PlayerCharacter.transform.position);
        }

  
    }

   

    public override void CharacterSetting()
    {
        base.CharacterSetting();

        PlayerCharacter = GameObject.FindGameObjectWithTag("Player");
        PlayerCharacterComponent = PlayerCharacter.GetComponent<Player>();
        PlayerCharacterComponent.MonsterCharacter = gameObject;

        //사정거리
        Range = 1.5f;

        HP = 30;
    }


    //hp가 다되면 소멸
    public override void DestoryCharacter()
    {
        PlayerCharacterComponent.animator.Play("Idle");
        PlayerCharacterComponent.MousePosition = PlayerCharacter.transform.position;

        base.DestoryCharacter();
    }
}
