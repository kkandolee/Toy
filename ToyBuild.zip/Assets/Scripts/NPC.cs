﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC : Character
{
    public GameObject PlayerCharacter;
    Player PlayerCharacterComponent;
    public GameObject MonsterCharacter;
    Monster MonsterCharacterComponent;
    public NPC NPC_NUM;
    public GameObject NPC_1_Character;

    float MoveSpeed = 5.0f;
    // Start is called before the first frame update
    void Start()
    {
        //CharacterSetting();
    }


    void FixedUpdate()
    {
        SetNPCBehavior();
    }

    //player기준으로 npc행동 설정
    public void SetNPCBehavior()
    {
        if(PlayerCharacterComponent.CurrentStatus == STATUS.ATTACK && MonsterCharacterComponent.isDie == false)
        {
            //npc1, npc2 분기처리
            if (NPC_NUM == NPC.NPC_1)
                //사정거리 제곱근으로 보간한다
                transform.position = Vector3.Lerp(transform.position, MonsterCharacter.transform.position + new Vector3(Mathf.Sqrt(Range) * 0.5f, Mathf.Sqrt(Range) * 0.5f, 0.0f), Time.deltaTime * MoveSpeed);
            else
                transform.position = Vector3.Lerp(transform.position, MonsterCharacter.transform.position - new Vector3(Mathf.Sqrt(Range) * 0.5f, Mathf.Sqrt(Range) * 0.5f, 0.0f), Time.deltaTime * MoveSpeed);

            CharacterDirection_X(MonsterCharacter.transform.position);
            CurrentStatus = STATUS.ATTACK;

            animator.Play("AttackNPC");
            
        }
        else
        {
            if (NPC_NUM == NPC.NPC_1)
                transform.position = Vector3.Lerp(transform.position, PlayerCharacter.transform.position + new Vector3(0.5f, 0.5f, 0.0f), Time.deltaTime * MoveSpeed);
            else
                transform.position = Vector3.Lerp(transform.position, NPC_1_Character.transform.position + new Vector3(0.5f, 0.5f, 0.0f), Time.deltaTime * MoveSpeed);

            if (transform.position.y < PlayerCharacter.transform.position.y)
            {
                CurrentStatus = STATUS.IDLE;
                animator.Play("IdleNPCBack");

                CharacterDirection_X(PlayerCharacter.transform.position);

            }
            else
            {
                CurrentStatus = STATUS.IDLE;
                animator.Play("IdleNPC");

                CharacterDirection_X(PlayerCharacter.transform.position);
            }
        }
        
    }

    public override void CharacterSetting()
    {
        base.CharacterSetting();

        PlayerCharacterComponent = PlayerCharacter.GetComponent<Player>();
        MonsterCharacterComponent = MonsterCharacter.GetComponent<Monster>();

        Range = 1.5f;
    }

    public void DemageMonster()
    {
        MonsterCharacterComponent.HP -= 1;
    }
}
