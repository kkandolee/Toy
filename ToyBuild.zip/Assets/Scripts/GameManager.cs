﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : Manager
{
    public Transform CharacterTransform;
    public NPC[] NPCCharacterComponents;
    public Player PlayerCharacterComponent;
    private void Awake()
    {
        Screen.SetResolution(1280, 720, true);
    }

    // Start is called before the first frame update
    void Start()
    {
        //몬스터 생성
        CreateMonster();


        //캐릭터 기본 세팅
        for(int i = 0; i < NPCCharacterComponents.Length; i++)
        {
            NPCCharacterComponents[i].CharacterSetting();
        }
        PlayerCharacterComponent.CharacterSetting();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    
    void CreateMonster()
    {
        //동적할당으로 몬스터를 생성
        GameObject prefab = Resources.Load("Prefabs/Monster") as GameObject;
        GameObject monster = Instantiate(prefab) as GameObject;
        monster.transform.SetParent(CharacterTransform, false);
        monster.transform.position = new Vector3(Random.Range(-5.0f, 5.0f), Random.Range(-2.0f, 2.0f), 0.0f);


        for (int i = 0; i < NPCCharacterComponents.Length; i++)
        {
            NPCCharacterComponents[i].MonsterCharacter = monster;
        }

        PlayerCharacterComponent.MonsterCharacter = monster;
    }
}
