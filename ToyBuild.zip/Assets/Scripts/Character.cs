﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//monster, npc, player 상속하는 클래스
public class Character : MonoBehaviour
{
    
    public Animator animator;

    public enum STATUS
    {
        IDLE,
        ATTACK
    }

    public enum NPC
    {
        NPC_1,
        NPC_2
    }

    public STATUS CurrentStatus;

    protected float Range;
    public int HP;

    public bool isDie = false;
    // Start is called before the first frame update
    void Start()
    { 
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    virtual public void CharacterSetting()
    {
        animator = GetComponent<Animator>();
        CurrentStatus = STATUS.IDLE;
    }

    protected void CharacterDirection_X(Vector3 target)
    {
        if (transform.position.x < target.x)
        {
            transform.localScale = new Vector3(-1.0f, transform.localScale.y, transform.localScale.z);
        }
        else
        {
            transform.localScale = new Vector3(1.0f, transform.localScale.y, transform.localScale.z);
        }
    }
    virtual public void DestoryCharacter()
    {
        Destroy(gameObject);
    }
}
