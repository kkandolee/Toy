﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Character
{
    public Vector2 MousePosition;
    public Camera Camera;
    float MoveSpeed = 5.0f;
    public GameObject MonsterCharacter;
    Monster MonsterCharacterComponent;

    // Start is called before the first frame update
    void Start()
    {
        //CharacterSetting();

    }

    void FixedUpdate()
    {
        CharacterDirection();
    }

    public override void CharacterSetting()
    {
        base.CharacterSetting();

        MonsterCharacterComponent = MonsterCharacter.GetComponent<Monster>();

        Range = 1.5f;
    }

    public void CharacterDirection()
    {
        //마우스 입력
        if(Input.GetMouseButtonDown(0))
        {
            MousePosition = Input.mousePosition;
            MousePosition = Camera.ScreenToWorldPoint(MousePosition);

            if(transform.position.y < MousePosition.y)
            {
                animator.Play("IdleBack");
                CharacterDirection_X(MousePosition);
            }
            else
            {
                animator.Play("Idle");
                CharacterDirection_X(MousePosition);
            }

        }

        MovePlayer();

    }

    

    void MovePlayer()
    {
        transform.position = Vector3.MoveTowards(transform.position, MousePosition, Time.deltaTime * MoveSpeed);

        CheckMonster();
    }

    void CheckMonster()
    {
        if(MonsterCharacterComponent.isDie == true)
        {
            return;
        }

        if (transform.position.y < MonsterCharacter.transform.position.y)
        {
            if (Vector2.Distance(MonsterCharacter.transform.position, transform.position) <= Range)
            {
                CurrentStatus = STATUS.ATTACK;
                animator.Play("AttackBack");
            }
            else
            {
                if(CurrentStatus == STATUS.ATTACK)
                {
                    CurrentStatus = STATUS.IDLE;
                    animator.Play("Idle");
                    CharacterDirection_X(MousePosition);
                }
                
            }
        }
        else
        {
            if (Vector2.Distance(MonsterCharacter.transform.position, transform.position) <= Range)
            {
                CurrentStatus = STATUS.ATTACK;
                animator.Play("Attack");
            }
            else
            {
                if (CurrentStatus == STATUS.ATTACK)
                {
                    CurrentStatus = STATUS.IDLE;
                    animator.Play("IdleBack");
                    CharacterDirection_X(MousePosition);
                }
            }
        }
    }

    public void DemageMonster()
    {
        MonsterCharacterComponent.HP -= 1;
    }
}
